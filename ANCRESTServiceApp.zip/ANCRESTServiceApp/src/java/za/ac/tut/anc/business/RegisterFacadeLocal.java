/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.anc.business;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.anc.entities.Register;

/**
 *
 * @author leseg
 */
@Local
public interface RegisterFacadeLocal {

    void create(Register register); // it must go check the Department of home affairs // the opt must be sent

    void edit(Register register);

    void remove(Register register);

    Register find(Object id);

    List<Register> findAll();

    List<Register> findRange(int[] range);

    int count();
    
}
