/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.anc.business;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.anc.entities.Register;

/**
 *
 * @author leseg
 */
@Stateless
public class RegisterFacade extends AbstractFacade<Register> implements RegisterFacadeLocal {
    @PersistenceContext(unitName = "ANCRESTServiceAppPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RegisterFacade() {
        super(Register.class);
    }
    
}
